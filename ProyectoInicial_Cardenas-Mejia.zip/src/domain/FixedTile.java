package domain;

/**
 * Write a description of class fixedTile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FixedTile extends Tile {
    public FixedTile(String color) {
        super(color);
    }

    @Override
    public void makeInvisible() {
        System.out.println("Esta ficha no se puede eliminar.");
    }

	@Override
	public boolean canMove() {
		return false;
	}

	@Override
	public boolean canStick() {
		return true;
	}
    
	@Override
	public boolean canBeDeleted() {
		return false;
	}

	@Override
	public String getType() {
		return "Fixed";
	}	
  
}