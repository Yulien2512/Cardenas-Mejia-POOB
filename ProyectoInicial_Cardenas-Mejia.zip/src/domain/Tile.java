package domain;
import presentation.Circle;
import presentation.Rectangle;

public abstract class Tile {
    private Rectangle tile;
    private Circle glueCircle;
    private boolean hasGlue;
    private int groupId;
    private int x;
    private int y;
    private static int groupCounter = 0;

    public Tile(String color) {
        this.tile = new Rectangle();
        this.tile.changeSize(40, 40);
        this.tile.changeColor(color);
        this.hasGlue = false;
        this.glueCircle = null;
        this.groupId = -1;
    }

    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
        tile.moveVertical(x * 50);
        tile.moveHorizontal(y * 50);
    }

    public int getRow() {
        return x;
    }

    public int getCol() {
        return y;
    }

    public int getGroupId() {
        return this.groupId;
    }

    public void addGroup(Tile tile, int id) {
        tile.setGroupId(id);
    }
    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public void changeColor(String color){
        this.tile.changeColor(color);
    }

    public static void createGroup(Tile tile) {
        int newGroupId = ++groupCounter;
        tile.setGroupId(newGroupId);
    }

    public static int countGroups() {
        return groupCounter;
    }

    public void makeVisible() {
        tile.makeVisible();
    }

    public void makeInvisible() {
        tile.makeInvisible();
    }

    public void moveHorizontal(int distance) {
        tile.moveHorizontal(distance);
    }

    public void glue() {
        this.hasGlue = true;
    }

    public void removeGlue() {
        this.hasGlue = false;
    }

    public boolean hasGlue() {
        return hasGlue;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getColor() {
        return tile.getColor();
    }

    public abstract boolean canMove(); // Método abstracto para determinar si puede moverse

    public abstract boolean canStick();
    
    public abstract boolean canBeDeleted();

    public abstract String getType();
}
