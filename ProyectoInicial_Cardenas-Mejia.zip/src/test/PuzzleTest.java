package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import domain.Puzzle;
import domain.Tile;

/**
 * The test class PuzzleTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PuzzleTest
{
    private Puzzle puzzle; 
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        String [] board = {"....", "....","....","...."};
        String [] lastBoard = {"....","....","....","...."};
        puzzle = new Puzzle(board,lastBoard); 
    }
    
    @Test
    public void shouldNotCreateAPuzzleWithAInvalidColor(){
        String [] board = {"r..r", "br.y","...b"};
        String [] lastBoard = {"rbyr","brwy","rbrb"};
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Puzzle(board, lastBoard);
        });
        assertEquals("Carácter no reconocido: w", exception.getMessage());
    }
    
    @Test
    public void shouldNotAddTile(){
        String [] board = {"r..r", "br.y","...b"};
        String [] lastBoard = {"rbyr","brby","rbrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        assertTrue(puzzle.isOk());
        puzzle.addTile(5,6,"blue");
        boolean answer = puzzle.isOk();
        assertTrue(!answer);
    }
    
    @Test
    public void shouldAddTile(){
        String [] board = {"r..r", "br.y","...b"};
        String [] lastBoard = {"rbyr","brby","rbrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        assertTrue(puzzle.isOk());
        puzzle.addTile(2,1,"blue");
        boolean answer = puzzle.isOk();
        assertTrue(answer);
    }
    
    @Test
    public void shouldAddTileAndWin(){
        String [] board = {"rbyr", "brby","r.rb"};
        String [] objective = {"rbyr","brby","rbrb"};
        Puzzle puzzle = new Puzzle(board, objective);
        assertTrue(puzzle.isOk());
        puzzle.addTile(2,1,"blue");
        assertTrue(puzzle.isOk());
        puzzle.equals(objective);
    }
    
    @Test
    public void shouldReplaceATileWithGlue(){
        String [] board = {"rbyr", "brby","r.rb","...."};
        String [] objective = {"rbyr","brby","b.rb","...."};
        Puzzle puzzle = new Puzzle(board, objective);
        puzzle.addGlue(2,0);
        puzzle.addTile(2,0,"blue");
        Tile tile = puzzle.getTile(2,0);
        assertEquals(tile.getGroupId(),-1);
    }
    
    @Test
    public void shouldMoveATileWhenIsPossible(){
        String [] board = {"r.yr", "brby","brrb","...."};
        String [] lastBoard = {".ryr", "brby","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('r');
        assertEquals(null, puzzle.getTile(0,0));
    }
    
    @Test
    public void shouldNotMoveATileWhenIsNotPossible(){
        String [] board = {"rbyb", "....","....","...."};
        String [] lastBoard = {"rbyr", "....","....","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('r');
        assertNotEquals(null,puzzle.getTile(0,0));
    }
    
    @Test
    public void shouldDeleteTile(){
        String [] board = {"rbyr", "brby","brrb"};
        String [] lastBoard = {".byr", "brby","brrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.deleteTile(0,0);
        puzzle.equals(lastBoard);
    }
    
    @Test
    public void shouldNotDeleteTile(){
        String [] board = {"rbyr", "brby","brrb"};
        String [] lastBoard = {".byr", "brby","brrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.deleteTile(5,5);
        boolean answer = puzzle.equals(lastBoard);
        assertTrue(!answer);
    }
    
    @Test
    public void shouldRelocateATile(){
        String [] board = {"rbyr", "....","brrb"};
        String [] lastBoard = {"rbyr",".b..",".rrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.relocateTile(2,0,1,1);
        assertNotEquals(null,puzzle.getTile(1,1));
    }
    
    @Test
    public void shouldNotRelocateATileWhenIsNotPossible(){
        String [] board = {"rbyr", "....","brrb"};
        String [] lastBoard = {"rbyr","....","brrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.relocateTile(2,0,5,4);
        boolean answer = puzzle.isOk();
        assertTrue(!answer);
    }
    
    @Test
    public void shouldReplaceATile(){
        String [] board = {"rbyr", ".r..","brrb"};
        String [] lastBoard = {"rbyr",".b..",".rrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.relocateTile(2,0,1,1);
        assertNotEquals(null,puzzle.getTile(1,1));
        puzzle.isGoal();
    }
    
    @Test 
    public void shouldDeleteATileThatHasGlue(){
        String [] board = {"rbyr", ".b..","brrb","...."};
        String [] lastBoard = {"rbyr",".b..","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard); 
        puzzle.addGlue(1,1);
        Tile tile = puzzle.getTile(1,1);
        int answer = tile.getGroupId();
        assertNotEquals(answer,-1);
        puzzle.deleteTile(1,1);
        assertEquals(puzzle.getTile(1,1),null);
    }
    
    @Test  
    public void shouldAddGlueATile(){
        String [] board = {"rbyr", ".b..","brrb","...."};
        String [] lastBoard = {"rbyr",".b..","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,1);
        Tile tile = puzzle.getTile(1,1);
        int answer = tile.getGroupId();
        assertNotEquals(answer,-1);
    }
    
    @Test  
    public void shouldDeleteGlueATile(){
        String [] board = {"rbyr", ".b..","brrb","...."};
        String [] lastBoard = {"rbyr",".b..","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,1);
        puzzle.isGoal();
        puzzle.deleteGlue(1,1);
        Tile tile = puzzle.getTile(1,1);
        assertEquals(tile.getGroupId(),-1);
    }
    
    @Test
    public void shouldMatchTilesWithGlueAndMove(){
        String [] board = {".rb.", "....","....","..y."};
        String [] lastBoard = {"....","....",".rb.","..y."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(0,2);
        puzzle.tilt('d');
        assertNotEquals(null,puzzle.getTile(2,1));
        //assertNotEquals(null,puzzle.getTile(2,2)); 
    }
    
    @Test
    public void shouldNotMatchTilesWithGlueAndMoveWhenIsNotPossible(){
        String [] board = {"....", "r..b","....","...y"};
        String [] lastBoard = {"....",".....","...b",".r...y"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,0);
        puzzle.tilt('d');
        Tile tile = puzzle.getTile(2,3);
        assertEquals(tile.getGroupId(),-1);
    }
    
    @Test 
    public void shouldAssertTrueTilt(){
        String [] board = {"rbyr", "....","....","...."};
        String [] lastBoard = {"....","....","....","rbyr"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('d');
        boolean answer = puzzle.isGoal();
        assertTrue(answer);
    }
    
    @Test
    public void shouldAssertFalseTilt(){
        String [] board = {"rbyr", "....","...."};
        String [] lastBoard = {"rbyr","....","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('a');
        boolean answer = puzzle.isOk();
        assertFalse(answer);
    }
    
    @Test 
    public void shouldGetHeight(){
        String [] board = {"rbyr", ".r.b","y.r.","y.rr"};
        String [] lastBoard = {"rbyr",".r.b","y.r.","y.rr"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        int height = puzzle.getHeight();
        assertEquals(height,4);
    }
    
    @Test 
    public void shouldGetWidth(){
        String [] board = {"rbyr", ".r.b","y.r.","y.rr"};
        String [] lastBoard = {"rbyr",".r.b","y.r.","y.rr"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        int height = puzzle.getHeight();
        assertEquals(height,4);
    }
    
    @Test
    public void shoulMakeHole(){
        String [] board = {"rbyr", "....","ygrb"};
        String [] lastBoard = {"rbyr","....","ygrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(1,1);
        assertNotEquals(null,puzzle.getTile(1,1));
    }
    
    @Test
    public void shouldReplaceAHoleWithTile(){
        String [] board = {"....", "b...","r...","ygrb"};
        String [] lastBoard = {"bgrb","....","....","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(0,0);
        puzzle.tilt('u');
        assertNotEquals(null,puzzle.getTile(0,0));
        puzzle.addTile(0,0,"Blue");
        puzzle.isGoal();
    }
    
    @Test
    public void shouldDoNotMoveAHole(){
        String [] board = {".byr", "....","....","ygrb"};
        String [] lastBoard = {"....","....",".byr","ygrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(0,0);
        puzzle.tilt('d');
        assertNotEquals(null,puzzle.getTile(0,0));
    }
    
    @Test 
    public void shouldDeleteATileUsingAHole(){
        String [] board = {"rbyr", "....","....","ygrb"};
        String [] lastBoard = {"rbyr","y.rb","....","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(1,1);
        puzzle.tilt('u');
        assertNotEquals(puzzle.getTile(1,1),null);
        puzzle.isGoal();
    }
    
    @Test
    public void shouldNotRelocateAHole(){
        String [] board = {".byr", "grbb","ggyr","ygr."};
        String [] lastBoard = {".byr",".rbb",".gyr",".gr."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(0,0);
        puzzle.tilt('u');
        puzzle.relocateTile(0,0,3,3);
        assertEquals(puzzle.getTile(3,3),null);
        assertNotEquals(puzzle.getTile(0,0),null);
        puzzle.isGoal();
    }
    
    @Test
    public void shouldAssertTrueExchange() {
        String[] initialBoard = {"....", "....", "....","...."};
        String[] initialLastBoard = {"rbyr", "....", "ygrb","...."};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        boolean result = puzzle.exchange();
        assertTrue(result, "El método exchange debería retornar true si se ejecuta correctamente.");
    }

    @Test
    public void shouldMakeVisible() {
        String[] initialBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        String[] initialLastBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        assertDoesNotThrow(() -> puzzle.makeVisible());
    }
           
    @Test
    public void shouldMakeInvisible(){
        String[] initialBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        String[] initialLastBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        assertDoesNotThrow(() -> puzzle.makeInvisible());
    }
    
    @Test
    public void shouldFinishPuzzle(){
        String[] initialBoard = {"rbyg", "yrbr", "rybb","ybbg"};
        String[] initialLastBoard = {"rbyg", "yrbr", "rybb","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        assertDoesNotThrow(() -> puzzle.finish());
    }
}
