package test;
import org.junit.jupiter.api.Test;

import domain.PuzzleSolver;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
/**
 * Write a description of class PuzzleContestTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PuzzleContestTest
{
    // instance variables - replace the example below with your own
    @Test
    public void testOnePuzzleContest(){

        char[][] initial = { {'y', 'r', 'b', 'r'},
        {'.', '.', 'y', 'r'},
        {'.', '.', '.', 'g'},
        {'.', '.', '.', 'b'}};
            char[][] objective = {{'.', 'r', '.', '.',},
        {'r', 'g', 'y', 'b'},
        {'.', 'b', '.', '.'},
        {'.', 'y', 'r', '.'}};
        PuzzleSolver solver = new PuzzleSolver();
        boolean answer = solver.solve(objective, initial);
        assertTrue(answer);
    }
    
    @Test
    public void testTwoPuzzleContest(){
        char[][] initial =  {{'.', '.', '.', '.', 'x', '.', '.'}};
        char[][] objective = {{'.','.', 'x', '.', '.', '.', '.'}};
        PuzzleSolver solver = new PuzzleSolver();
        boolean answer = solver.solve(initial,objective);
        assertFalse(answer);
    }
    
    @Test
    public void testThreePuzzleContest(){
        char[][] initial = { {'y', 'r', '.'},
        {'.', '.', 'b'},
        {'r', 'y', '.'},
        {'b', '.', '.'}};
        char[][] objective = { {'.', '.', '.'},
        {'.', '.', 'b'},
        {'.', 'r', 'y'},
        {'b', 'y', 'b'}};
    
        PuzzleSolver solver = new PuzzleSolver();
        boolean answer = solver.solve(initial,objective);
        assertFalse(answer);
    }
}
