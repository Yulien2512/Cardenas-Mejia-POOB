package domain;

/**
 * Write a description of class FreelanceTile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FreelanceTile extends Tile {

    public FreelanceTile(String color) {
        super(color);
    }

    @Override
    public Tile clone() {
        return new FreelanceTile(getColor());
    }

    @Override
    public boolean canMove() {
        return true; // Las freelance pueden moverse
    }

    @Override
    public boolean canStick() {
        return false; // No se pueden pegar
    }

    @Override
    public boolean canBeDeleted(){
        return true; // Se pueden eliminar
    }
    
    @Override
    public String getType() {
        return "Freelance";
    }
}


