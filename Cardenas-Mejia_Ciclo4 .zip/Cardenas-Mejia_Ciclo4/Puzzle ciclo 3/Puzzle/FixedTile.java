
/**
 * Write a description of class fixedTile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FixedTile extends Tile {
    public FixedTile(String color) {
        super(color);
    }

    @Override
    public void makeInvisible() {
        System.out.println("Esta ficha no se puede eliminar.");
    }
    
  
}