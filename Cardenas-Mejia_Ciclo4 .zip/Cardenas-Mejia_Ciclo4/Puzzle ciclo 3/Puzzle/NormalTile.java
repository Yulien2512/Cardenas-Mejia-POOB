
public class NormalTile extends Tile {
    public NormalTile(String color) {
        super(color);
    }
    
    @Override
    public Tile clone() {
        return new NormalTile(this.color);
    }

    @Override
    public boolean canMove() {
        return true; // Las normales pueden moverse
    }

    @Override
    public boolean canStick() {
        return true; // Las normales se pueden pegar
    }
}


