
/**
 * Write a description of class RoughTile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RoughTile extends Tile {
    public RoughTile(String color) {
        super(color);
    }

 @Override
    public Tile clone() {
        return new RoughTile(this.color);
    }

    @Override
    public boolean canMove() {
        return false; // Las rough no se pueden mover
    }

    @Override
    public boolean canStick() {
        return true; // Pueden pegarse
    }
}
