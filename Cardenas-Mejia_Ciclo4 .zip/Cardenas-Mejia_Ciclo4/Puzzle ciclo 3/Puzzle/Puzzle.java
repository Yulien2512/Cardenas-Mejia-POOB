
import java.util.ArrayList;
import java.util.Collections;

public class Puzzle {
    private int height;
    private int width;
    private Tile[][] board;
    private Tile[][] lastBoard;
    private String[] order;
    private boolean[][] hole;
    private boolean isOk = true;
    private Glue[][] glue;
    private Rectangle background;    // Fondo del tablero inicial
    private Rectangle backgroundS;

    public Puzzle(int height, int width) {
        this.height = height;
        this.width = width;
        this.board = new Tile[width][height];
        this.lastBoard = new Tile[width][height];
        this.glue = new Glue[width][height];
        this.hole = new boolean[width][height];
        this.createBoards();
    }

    public Puzzle(String[] ending) {
        this.height = ending.length;
        this.width = ending[0].length();
        this.createlastBoardByOrder(ending);
        this.createBoardsAutomatically();
        this.hole = new boolean[width][height];
        this.glue = new Glue[width][height];
    }

    public Puzzle(String[] starting, String[] ending) {
        this.height = ending.length;
        this.width = ending[0].length();
        this.createlastBoardByOrder(ending);
        this.createBoardByOrder(starting);
        this.hole = new boolean[width][height];
        this.glue = new Glue[width][height];
    }

    public void makeVisible() {
        this.background(this.height, this.width);

        for (int i = 0; i < this.height; ++i) {
            for (int j = 0; j < this.width; ++j) {
                if (this.board[i][j] != null) {
                    this.board[i][j].makeVisible();
                } else {
                    this.board[i][j] = null;
                }

                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].makeVisible();
                } else {
                    this.lastBoard[i][j] = null;
                }
            }
        }

    }

    public void makeInvisible() {
        for (int i = 0; i < this.height; i++) {
            for (int j = 0; j < this.width; j++) {
                if (this.board[i][j] != null) {
                    this.board[i][j].makeInvisible();
                }
            }
        }

        for (int i = 0; i < this.height; i++) {
            for (int j = 0; j < this.width; j++) {
                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].makeInvisible();
                }
            }
        }
        if (this.background != null) {
            this.background.makeInvisible();
        }
        if (this.backgroundS != null) {
            this.backgroundS.makeInvisible();
        }
    }


    private void createlastBoardByOrder(String[] cadena) {
        int numFilas = cadena.length;
        int numColumnas = cadena[0].length();
        this.lastBoard = new Tile[numFilas][numColumnas];

        for (int i = 0; i < numFilas; ++i) {
            for (int j = 0; j < numColumnas; ++j) {
                char c = cadena[i].charAt(j);
                switch (c) {
                    case '.' -> this.lastBoard[i][j] = null;
                    case 'b' -> this.lastBoard[i][j] = new NormalTile("blue");
                    case 'g' -> this.lastBoard[i][j] = new NormalTile("green");
                    case 'r' -> this.lastBoard[i][j] = new NormalTile("red");
                    case 'y' -> this.lastBoard[i][j] = new NormalTile("yellow");
                    default -> throw new IllegalArgumentException("Carácter no reconocido: " + c);
                }

                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].setXY(i, j);
                    this.lastBoard[i][j].moveHorizontal(500);
                }
            }
        }

    }

    private void createBoardByOrder(String[] cadena) {
        int numFilas = cadena.length;
        int numColumnas = cadena[0].length();
        this.board = new Tile[numFilas][numColumnas];

        for (int i = 0; i < numFilas; ++i) {
            for (int j = 0; j < numColumnas; ++j) {
                char c = cadena[i].charAt(j);
                switch (c) {
                    case '.' -> this.board[i][j] = null;
                    case 'b' -> this.board[i][j] = new NormalTile("blue");
                    case 'g' -> this.board[i][j] = new NormalTile("green");
                    case 'r' -> this.board[i][j] = new NormalTile("red");
                    case 'y' -> this.board[i][j] = new NormalTile("yellow");
                    default -> throw new IllegalArgumentException("Carácter no reconocido: " + c);
                }

                if (this.board[i][j] != null) {
                    this.board[i][j].setXY(i, j);
                }
            }
        }

    }

    private void background(int height, int width) {
        this.background = new Rectangle();
        this.backgroundS = new Rectangle();
        background.changeSize(width * 51, height * 51);
        backgroundS.changeSize(width * 51, height * 51);
        background.changeColor("Grey");
        backgroundS.changeColor("Grey");
        background.makeVisible();
        background.moveTo(62, 14);
        backgroundS.moveTo(565, 14);
        backgroundS.makeVisible();
        background.changeColor("White");
        backgroundS.changeColor("White");

    }

    private void createBoards() {
        String[] colors = new String[]{"red", "yellow", "blue", "green"};
        int totalTiles = this.height * this.width;
        int colorTiles = totalTiles / 2;
        int emptyTiles = totalTiles - colorTiles;
        ArrayList<Tile> tiles = new ArrayList();
        ArrayList<Tile> tilesFinal = new ArrayList();

        int temp;
        for (temp = 0; temp < colorTiles; temp++) {
            Tile tile = new NormalTile(colors[temp % 4]);
            Tile tileFinal = new NormalTile(colors[temp % 4]);
            tiles.add(tile);
            tilesFinal.add(tileFinal);
        }

        for (temp = 0; temp < emptyTiles; ++temp) {
            tiles.add(null);
            tilesFinal.add(null);
        }

        Collections.shuffle(tiles);
        Collections.shuffle(tilesFinal);
        temp = 0;
        int tempF = 0;

        for (int i = 0; i < this.height; i++) {
            for (int j = 0; j < this.width; j++) {
                this.board[i][j] = (Tile) tiles.get(temp++);
                this.lastBoard[i][j] = (Tile) tilesFinal.get(tempF++);
                if (this.board[i][j] != null) {
                    this.board[i][j].setXY(i, j);
                }

                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].setXY(i, j);
                    this.lastBoard[i][j].moveHorizontal(500);
                }
            }
        }
    }



    private void createBoardsAutomatically() {
        String[] colors = new String[]{"red", "yellow", "blue", "green"};
        int totalTiles = this.height * this.width;
        int colorTiles = totalTiles / 2;
        int emptyTiles = totalTiles - colorTiles;
        ArrayList<Tile> tiles = new ArrayList();

        int temp;
        for (temp = 0; temp < colorTiles; ++temp) {
            Tile tile = new NormalTile(colors[temp % 4]);
            tiles.add(tile);
        }

        for (temp = 0; temp < emptyTiles; ++temp) {
            tiles.add(null);
        }

        Collections.shuffle(tiles);
        temp = 0;
        this.board = new Tile[this.height][this.width];

        for (int i = 0; i < this.height; ++i) {
            for (int j = 0; j < this.width; ++j) {
                this.board[i][j] = (Tile) tiles.get(temp++);
                if (this.board[i][j] != null) {
                    this.board[i][j].setXY(i, j);
                }
            }
        }

    }

    public int getHeight() {
        return this.height;
    }

    public int getWidth() {
        return this.width;
    }

    private void setTile(int row, int column, Tile tile) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            this.board[row][column] = tile;
        }

    }

    public void addTile(int row, int column, String color) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            Tile newTile = new NormalTile(color);
            newTile.setXY(row, column);
            setTile(row, column, newTile);
            newTile.makeVisible();
            isOk = true;
        } else {
            System.out.println("Posición fuera de los límites del tablero.");
            isOk = false;
        }

    }

    private void addTileToRelocate(int row, int column, String color, boolean hasGlue, int groupId) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            Tile newTile = new NormalTile(color);
            newTile.setXY(row, column);
            if (hasGlue) {
                newTile.glue();
            }
            this.setTile(row, column, newTile);
            newTile.setGroupId(groupId);
            newTile.makeVisible();
            if (newTile.hasGlue()) {
                makeVisibleGlue();
            }
        } else {
            System.out.println("Posición fuera de los límites del tablero.");
        }
    }

    public void addTile(int row, int column, String tileType, String color) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            Tile newTile;

            switch (tileType.toLowerCase()) {
                case "normal":
                    newTile = new NormalTile(color);
                    break;
                case "fixed":
                    newTile = new FixedTile(color);
                case "rough":
                    newTile = new RoughTile(color);
                    break;
                case "freelance":
                    newTile = new FreelanceTile(color);
                    break;
                case "flying":
                    newTile = new FlyingTile(color);
                    break;
                default:
                    throw new IllegalArgumentException("Tipo de tile no reconocido: " + tileType);
            }

            newTile.setXY(row, column);
            setTile(row, column, newTile);
            newTile.makeVisible();
            isOk = true;
        } else {
            System.out.println("Posición fuera de los límites del tablero.");
            isOk = false;
        }
    }


    public boolean isOk(){
        return isOk;
    }

    public void deleteTile(int row, int column) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            Tile tile = this.getTile(row, column);
            if (tile != null) {
                this.board[row][column] = null;
                tile.makeInvisible();
            }
        }

    }

    public void relocateTile(int oldRow, int oldColumn, int newRow, int newColumn) {
        if (oldRow >= 0 && oldRow < this.height && oldColumn >= 0 && oldColumn < this.width && newRow >= 0 && newRow < this.height && newColumn >= 0 && newColumn < this.width) {
            Tile tile = this.getTile(oldRow, oldColumn);
            if (tile != null && this.board[newRow][newColumn] == null && !tile.getColor().equals("white")) {
                deleteTile(oldRow, oldColumn);
                String color = tile.getColor();
                int group = tile.getGroupId();
                boolean hasGlue = tile.hasGlue();
                if (tile.hasGlue()){
                    glue[oldRow][oldColumn].makeInvisible();
                }
                addTileToRelocate(newRow, newColumn, color, hasGlue, group);
            }
            isOk = true;
        }
        else{
            System.out.println("Posición fuera de los límites del tablero.");
            isOk = false;
        }
    }

    private void makeVisibleGlue() {
        for (int i = 0; i < this.height; ++i) {
            for (int j = 0; j < this.width; ++j) {
                Tile tile = this.getTile(i, j);
                if (tile != null && tile.hasGlue()) {
                    if (glue[i][j] == null) {
                        glue[i][j] = new Glue(i, j);
                    }
                    glue[i][j].setPosition(tile.getX(), tile.getY());
                    glue[i][j].makeVisible();
                } else {
                    if (glue[i][j] != null) {
                        glue[i][j].makeInvisible();
                        glue[i][j] = null;
                    }
                }
            }
        }
    }

    public void addGlue(int row, int col) {
        if (row >= 0 && row < this.height && col >= 0 && col < this.width && this.board[row][col] != null) {
            Tile tile = this.board[row][col];
            tile.glue();
            makeVisibleGlue();
            if (tile.getGroupId() == -1) {
                Tile.createGroup(tile);
            }

            int id = tile.getGroupId();
            if (row > 0 && this.board[row - 1][col] != null) {
                this.board[row - 1][col].addGroup(this.board[row - 1][col], id);
            }
            if (row < this.height - 1 && this.board[row + 1][col] != null) {
                this.board[row + 1][col].addGroup(this.board[row + 1][col], id);
            }
            if (col > 0 && this.board[row][col - 1] != null) {
                this.board[row][col - 1].addGroup(this.board[row][col - 1], id);
            }
            if (col < this.width - 1 && this.board[row][col + 1] != null) {
                this.board[row][col + 1].addGroup(this.board[row][col + 1], id);
            }
        }
    }

    public void deleteGlue(int row, int col) {
        if (row >= 0 && row < this.height && col >= 0 && col < this.width && this.board[row][col] != null) {
            Tile tile = this.board[row][col];
            tile.setGroupId(-1);
            tile.removeGlue();
            if (glue[row][col] != null) {
                glue[row][col].makeInvisible();
                glue[row][col] = null;
            }

            if (row > 0 && this.board[row - 1][col] != null) {
                this.board[row - 1][col].setGroupId(-1);
            }
            if (row < this.height - 1 && this.board[row + 1][col] != null) {
                this.board[row + 1][col].setGroupId(-1);
            }
            if (col > 0 && this.board[row][col - 1] != null) {
                this.board[row][col - 1].setGroupId(-1);
            }
            if (col < this.width - 1 && this.board[row][col + 1] != null) {
                this.board[row][col + 1].setGroupId(-1);
            }
        }
    }

    public void tilt(char direction) {
        int row;
        int col;
        Tile tile;
        switch (direction) {
            case 'd':
                this.moveTileDownTotal();
                isOk = true;
                return;
            case 'l':
                this.moveTileLeftTotal();
                isOk = true;
                return;
            case 'r':
                this.moveTileRightTotal();
                isOk = true;
                return;
            case 'u':
                this.moveTileUpTotal();
                isOk = true;
                return;

            default:
                System.out.println("Dirección no válida");
                isOk = false;
        }
    }

    private void moveTileUpTotal() {
        Tile tile;
        int row;
        int col;
        for (row = 0; row < this.height; ++row) {
            for (col = 0; col < this.width; ++col) {
                tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == -1) {
                    this.moveTileUp(row, col);
                } else if (tile != null && tile.getGroupId() != -1){
                    this.moveTileUpGroups(row, col);
                }
            }
        }
    }

    private void moveTileUp(int fila, int columna) {
        for (int i = fila - 1; i >= 0; --i) {
            if (this.hole[i][columna]) {
                this.deleteTile(fila, columna);
                break;
            }

            if (i == 0) {
                this.relocateTile(fila, columna, i, columna);
                break;
            }

            Tile tile = this.getTile(i - 1, columna);
            if (tile != null && !this.hole[i - 1][columna]) {
                this.relocateTile(fila, columna, i, columna);
                break;
            }
        }

    }

    private void moveTileUpGroups(int fila, int columna) {
        Tile tile = this.getTile(fila, columna);
        int minMovimientos = this.minCalculateMovementsUp(tile.getGroupId());
        System.out.println("El mínimo de movimientos para el grupo " + " es: " + minMovimientos);

        for (int i = fila - 1; i >= 0; --i) {
            if (i == 0) {
                this.relocateTile(fila, columna, fila - minMovimientos, columna);
                break;
            }

            this.getTile(i - 1, columna);
            if (tile != null && !this.hole[i - 1][columna]) {
                this.relocateTile(fila, columna, fila - minMovimientos, columna);
                break;
            }
        }

    }

    private int calculateMovementsUp(Tile tile, int fila, int columna) {
        int movements = 0;
        for (int i = fila - 1; i >= 0; --i) {
            Tile tileI = this.getTile(i, columna);
            if (tileI == null) {
                movements++;
            }
        }
        return movements;
    }

   private int minCalculateMovementsUp(int groupId) {
        int minMovements = 10000;
        for (int row = 0; row <= this.height; row++) {
            for (int col = 0; col <= this.width; col++) {
                Tile tile = this.getTile(row, col);
                System.out.print("llegamos" + "\n");
                if (row > 0){
                    if (tile != null && tile.getGroupId() == groupId) {
                            System.out.print(calculateMovementsUp(tile, row, col) + "-" + minMovements + "\n");
                            if (minMovements > calculateMovementsUp(tile, row, col)) {
                                minMovements = calculateMovementsUp(tile, row, col);

                        }
                    }
                }
            }
        }
        return minMovements;
    }

    private void moveTileDownTotal() {
        Tile tile;
        int row;
        int col;

        // Recorremos de abajo hacia arriba para mover las fichas.
        for (row = this.height - 1; row >= 0; --row) {
            for (col = 0; col < this.width; ++col) {
                tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == -1) {
                    this.moveTileDown(row, col); // Mueve una ficha individual
                } else if (tile != null && tile.getGroupId() != -1) {
                    this.moveTileDownGroups(row, col); // Mueve las fichas en grupo
                }
            }
        }
    }

    private void moveTileDown(int fila, int columna) { 
        for (int i = fila + 1; i < this.height; ++i) {
            if (this.hole[i][columna]) { // Verificamos si hay un hueco (posición vacía)
                this.deleteTile(fila, columna); // Eliminamos la ficha de su posición actual
                break;
            }

            if (i == this.height - 1) { // Llegamos al final del tablero
                this.relocateTile(fila, columna, i, columna); // Reubicamos la ficha en la última fila
                break;
            }

            Tile tile = this.getTile(i + 1, columna);
            if (tile != null && !this.hole[i + 1][columna]) { // Si encontramos una ficha debajo
                this.relocateTile(fila, columna, i, columna); // Movemos la ficha a la posición inmediatamente inferior
                break;
            }
        }
    }

    private void moveTileDownGroups(int fila, int columna) {
        Tile tile = this.getTile(fila, columna);
        int minMovimientos = this.minCalculateMovementsDown(tile.getGroupId());
        System.out.println("El mínimo de movimientos para el grupo " + tile.getGroupId() + " es: " + minMovimientos);

        for (int i = fila + 1; i < this.height; ++i) {
            if (i == this.height - 1) { // Llegamos al final del tablero
                this.relocateTile(fila, columna, fila + minMovimientos, columna); // Reubicamos la ficha según el número mínimo de movimientos
                break;
            }

            Tile tileBelow = this.getTile(i + 1, columna);
            if (tileBelow != null && !this.hole[i + 1][columna]) { // Si encontramos una ficha o un obstáculo debajo
                this.relocateTile(fila, columna, fila + minMovimientos, columna); // Movemos la ficha en grupo
                break;
            }
        }
    }

    private int calculateMovementsDown(Tile tile, int fila, int columna) {
        int movements = 0;
        for (int i = fila + 1; i < this.height; ++i) { // Recorremos hacia abajo
            Tile tileI = this.getTile(i, columna);
            if (tileI == null) { // Si no hay una ficha en la posición actual
                movements++; // Aumentamos los movimientos posibles
            }
        }
        return movements;
    }

    private int minCalculateMovementsDown(int groupId) {
        int minMovements = Integer.MAX_VALUE;

        for (int row = 0; row < this.height; row++) {
            for (int col = 0; col < this.width; col++) {
                Tile tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == groupId) {
                    int movimientos = this.calculateMovementsDown(tile, row, col);
                    if (movimientos < minMovements) {
                        minMovements = movimientos; // Actualizamos el mínimo de movimientos para el grupo
                    }
                }
            }
        }

        return minMovements;
    }


    private void moveTileLeftTotal() {
        Tile tile;
        int row;
        int col;
        for (col = 0; col < this.width; ++col) {
            for (row = 0; row < this.height; ++row) {
                tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == -1) {
                    this.moveTileLeft(row, col);
                } else if (tile != null && tile.getGroupId() != -1) {
                    this.moveTileLeftGroups(row, col);
                }
            }
        }
    }

    private void moveTileLeft(int row, int col) {
        for (int j = col - 1; j >= 0; --j) {
            if (this.hole[row][j]) {
                this.deleteTile(row, col);
                break;
            }

            if (j == 0) {
                this.relocateTile(row, col, row, j);
                break;
            }

            Tile tile = this.getTile(row, j - 1);
            if (tile != null && !this.hole[row][j - 1]) {
                this.relocateTile(row, col, row, j);
                break;
            }
        }
    }

    private void moveTileLeftGroups(int row, int col) {
        Tile tile = this.getTile(row, col);
        int minMovimientos = this.minCalculateMovementsLeft(tile.getGroupId());

        for (int j = col - 1; j >= 0; --j) {
            if (j == 0) {
                this.relocateTile(row, col, row, col - minMovimientos);
                break;
            }

            this.getTile(row, j - 1);
            if (tile != null && !this.hole[row][j - 1]) {
                this.relocateTile(row, col, row, col - minMovimientos);
                break;
            }
        }
    }

    private int calculateMovementsLeft(Tile tile, int row, int col) {
        int movements = 0;
        for (int j = col - 1; j >= 0; --j) {
            Tile tileJ = this.getTile(row, j);
            if (tileJ == null) {
                movements++;
            }
        }
        return movements;
    }

    private int minCalculateMovementsLeft(int groupId) {
        int minMovements = Integer.MAX_VALUE;
        for (int row = 0; row < this.height; row++) {
            for (int col = 0; col < this.width; col++) {
                Tile tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == groupId) {
                    int movements = calculateMovementsLeft(tile, row, col);
                    if (movements < minMovements) {
                        minMovements = movements;
                    }
                }
            }
        }
        return minMovements;
    }

    private void moveTileRightTotal() {
        Tile tile;
        int row;
        int col;
        for (col = this.width - 1; col >= 0; --col) {
            for (row = 0; row < this.height; ++row) {
                tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == -1) {
                    this.moveTileRight(row, col);
                } else if (tile != null && tile.getGroupId() != -1) {
                    this.moveTileRightGroups(row, col);
                }
            }
        }
    }

    private void moveTileRight(int row, int col) {
        for (int j = col + 1; j < this.width; ++j) {
            if (this.hole[row][j]) {
                this.deleteTile(row, col);
                break;
            }

            if (j == this.width - 1) {
                this.relocateTile(row, col, row, j);
                break;
            }

            Tile tile = this.getTile(row, j + 1);
            if (tile != null && !this.hole[row][j + 1]) {
                this.relocateTile(row, col, row, j);
                break;
            }
        }
    }

    private void moveTileRightGroups(int row, int col) {
        Tile tile = this.getTile(row, col);
        int minMovimientos = this.minCalculateMovementsRight(tile.getGroupId());

        for (int j = col + 1; j < this.width; ++j) {
            if (j == this.width - 1) {
                this.relocateTile(row, col, row, col + minMovimientos);
                break;
            }

            this.getTile(row, j + 1);
            if (tile != null && !this.hole[row][j + 1]) {
                this.relocateTile(row, col, row, col + minMovimientos);
                break;
            }
        }
    }

    private int calculateMovementsRight(Tile tile, int row, int col) {
        int movements = 0;
        for (int j = col + 1; j < this.width; ++j) {
            Tile tileJ = this.getTile(row, j);
            if (tileJ == null) {
                movements++;
            }
        }
        return movements;
    }

    private int minCalculateMovementsRight(int groupId) {
        int minMovements = Integer.MAX_VALUE;
        for (int row = 0; row < this.height; row++) {
            for (int col = 0; col < this.width; col++) {
                Tile tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == groupId) {
                    int movements = calculateMovementsRight(tile, row, col);
                    if (movements < minMovements) {
                        minMovements = movements;
                    }
                }
            }
        }
        return minMovements;
    }


    public void makeHole(int row, int col) {
        if (row <= this.height && row >= 0 && col <= this.width && col >= 0 && !this.hole[row][col]) {
            this.hole[row][col] = true;
            Tile tile = this.getTile(row, col);
            if (tile != null) {
                this.deleteTile(row, col);
            }

            this.addTile(row, col, "white");
        }
    }

    public int misplacedTiles() {
        int height = board.length;
        int width = board[0].length;
        int misplaceCount = 0;

        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width; col++) {
                Tile tile1 = board[row][col];
                Tile tile2 = lastBoard[row][col];
                if (tile1 == null && tile2 != null || tile1 != null && tile2 == null) {
                    misplaceCount++;
                } else if (tile1 != null && tile2 != null && !tile1.equals(tile2)) {
                    misplaceCount++;
                }
            }
        }
        return misplaceCount;
    }

    private char[][] getActualArragment(){
        char[][] actualArragment = new char[this.height][this.width];


        for (int i = 0; i < this.height; ++i) {
            for (int j = 0; j < this.width; ++j) {
                Tile tile = this.getTile(i, j);
                if (tile == null) {
                    actualArragment[i][j] = '*';
                } else {
                    switch (tile.getColor()) {
                        case "red":
                            actualArragment[i][j] = 'r';
                            break;
                        case "yellow":
                            actualArragment[i][j] = 'y';
                            break;
                        case "green":
                            actualArragment[i][j] = 'g';
                            break;
                        case "blue":
                            actualArragment[i][j] = 'b';
                            break;
                        default:
                            actualArragment[i][j] = '?';
                    }
                }
            }
        }
        return actualArragment;
    }



    public boolean exchange() {

        Tile[][] tempBoard = new Tile[height][width];


        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                tempBoard[i][j] = this.board[i][j];
            }
        }


        for (int j = 0; j < height; ++j) {
            for (int i = 0; i < width; ++i) {
                this.board[i][j] = this.lastBoard[i][j];
                if(board[i][j] != null) {
                    this.board[i][j].moveHorizontal(-500);
                }
                            }
        }


        for (int j = 0; j < height; ++j) {
            for (int i = 0; i < width; ++i) {
                this.lastBoard[i][j] = tempBoard[i][j];
                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].moveHorizontal(500);
                }
            }
        } 
        this.makeVisible();
        return true;
    }

    public boolean isGoal() {
        for (int i = 0; i < this.height; i++) {
            for (int j = 0; j < this.width; j++) {
                Tile currentTile = this.board[i][j];
                Tile lastTile = this.lastBoard[i][j];
                if (currentTile == null && lastTile == null) {
                    continue;
                }
                if (currentTile == null || lastTile == null) {
                    return false;
                }
                if (!currentTile.getColor().equals(lastTile.getColor())) {
                    return false;
                }
            }
        }
        return true;
    }

    public void ActualArragment(){
        char[][] boardArragment = getActualArragment();

        for (int i = 0; i < boardArragment.length; i++) {
            for (int j = 0; j < boardArragment[i].length; j++) {
                System.out.print(boardArragment[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void finish(){
        makeInvisible();;
    }

    public Tile getTile(int row, int col) {
        if (row >= 0 && row < this.height && col >= 0 && col < this.width) {
            return this.board[row][col];
        } else {
            return null;
        }
    }
    
    
}



