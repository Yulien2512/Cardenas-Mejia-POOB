
/**
 * Write a description of class FlyingTile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FlyingTile extends Tile {

    public FlyingTile(String color) {
        super(color);
    }

    @Override
    public Tile clone() {
        return new FlyingTile(this.color);
    }

    @Override
    public boolean canMove() {
        return true; 
    }

    @Override
    public boolean canStick() {
        return true; 
    }
}
