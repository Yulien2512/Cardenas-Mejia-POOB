package domain;

import presentation.Circle;

public class Glue {
    private Circle glueCircle;
    private int row;
    private int col;

    public Glue(int row, int col) {
        this.glueCircle = new Circle();
        this.glueCircle.changeSize(25);
        this.glueCircle.changeColor("white");
        this.row = row;
        this.col = col;
    }

    public void setPosition(int x, int y) {
        glueCircle.moveHorizontal((y * 50) + 8);
        glueCircle.moveVertical((x * 50) + 8);
    }

    public void makeVisible() {
        glueCircle.makeVisible();
    }

    public void makeInvisible() {
        glueCircle.makeInvisible();
    }
}
