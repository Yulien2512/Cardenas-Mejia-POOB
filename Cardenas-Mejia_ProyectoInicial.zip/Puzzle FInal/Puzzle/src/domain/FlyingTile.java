package domain;

/**
 * Write a description of class FlyingTile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FlyingTile extends Tile {

    public FlyingTile(String color) {
        super(color);
    }

    @Override
    public Tile clone() {
        return new FlyingTile(getColor());
    }

    @Override
    public boolean canMove() {
        return true; 
    }

    @Override
    public boolean canStick() {
        return true; 
    }

    @Override
    public boolean canBeDeleted(){
        return true; 
    }

    @Override
    public String getType() {
        return "Flying";
    }
}
