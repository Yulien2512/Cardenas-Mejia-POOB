package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import domain.Puzzle;
import domain.Tile;

public class PuzzleTest
{
    private Puzzle puzzle; 
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        String [] board = {"r..r", "br.y","...b",".b.y"};
        String [] lastBoard = {"rbyr","brby","rbrb","rbry"};
        puzzle = new Puzzle(board,lastBoard);
        puzzle.makeInvisible();
    }
    
   
    
    @Test
    public void shouldNotAddTile(){
        String [] board = {"r..r", "br.y","...b"};
        String [] lastBoard = {"rbyr","brby","rbrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        assertTrue(puzzle.isOk());
        puzzle.addTile(5,6,"blue");
        boolean answer = puzzle.isOk();
        assertTrue(!answer);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldAddTile(){
        String [] board = {"r..r", "br.y","...b"};
        String [] lastBoard = {"rbyr","brby","rbrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        assertTrue(puzzle.isOk());
        puzzle.addTile(2,1,"blue");
        boolean answer = puzzle.isOk();
        assertTrue(answer);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldAddTileAndWin(){
        String [] board = {"rbyr", "brby","r.rb"};
        String [] objective = {"rbyr","brby","rbrb"};
        Puzzle puzzle = new Puzzle(board, objective);
        assertTrue(puzzle.isOk());
        puzzle.addTile(2,1,"blue");
        assertTrue(puzzle.isOk());
        puzzle.equals(objective);
        puzzle.makeInvisible();
    }
    
    
    
    @Test
    public void shouldReplaceATileWithGlue(){
        String [] board = {"rbyr", "brby","r.rb","...."};
        String [] objective = {"rbyr","brby","b.rb","...."};
        Puzzle puzzle = new Puzzle(board, objective);
        puzzle.addGlue(2,0);
        puzzle.addTile(2,0,"blue");
        Tile tile = puzzle.getTile(2,0);
        assertEquals(tile.getGroupId(),-1);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldMoveATileWhenIsPossible(){
        String [] board = {"r.yr", "brby","brrb","...."};
        String [] lastBoard = {".ryr", "brby","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('r');
        assertEquals(null, puzzle.getTile(0,0));
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldNotMoveATileWhenIsNotPossible(){
        String [] board = {"rbyb", "....","....","...."};
        String [] lastBoard = {"rbyr", "....","....","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('r');
        assertNotEquals(null,puzzle.getTile(0,0));
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldDeleteTile(){
        String [] board = {"rbyr", "brby","brrb"};
        String [] lastBoard = {".byr", "brby","brrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.deleteTile(0,0);
        puzzle.equals(lastBoard);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldNotDeleteTile(){
        String [] board = {"rbyr", "brby","brrb"};
        String [] lastBoard = {".byr", "brby","brrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.deleteTile(5,5);
        boolean answer = puzzle.equals(lastBoard);
        assertTrue(!answer);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldRelocateATile(){
        String [] board = {"rbyr", "....","brrb"};
        String [] lastBoard = {"rbyr",".b..",".rrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.relocateTile(2,0,1,1);
        assertNotEquals(null,puzzle.getTile(1,1));
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldNotRelocateATileWhenIsNotPossible(){
        String [] board = {"rbyr", "....","brrb"};
        String [] lastBoard = {"rbyr","....","brrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.relocateTile(2,0,5,4);
        boolean answer = puzzle.isOk();
        assertTrue(!answer);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldReplaceATile(){
        String [] board = {"rbyr", ".r..","brrb"};
        String [] lastBoard = {"rbyr",".b..",".rrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.relocateTile(2,0,1,1);
        assertNotEquals(null,puzzle.getTile(1,1));
        puzzle.isGoal();
        puzzle.makeInvisible();
    }
    
    @Test 
    public void shouldDeleteATileThatHasGlue(){
        String [] board = {"rbyr", ".b..","brrb","...."};
        String [] lastBoard = {"rbyr",".b..","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard); 
        puzzle.addGlue(1,1);
        Tile tile = puzzle.getTile(1,1);
        int answer = tile.getGroupId();
        assertNotEquals(answer,-1);
        puzzle.deleteTile(1,1);
        assertEquals(puzzle.getTile(1,1),null);
        puzzle.makeInvisible();
    }
    
    
    
    @Test  
    public void shouldAddGlueATile(){
        String [] board = {"rbyr", ".b..","brrb","...."};
        String [] lastBoard = {"rbyr",".b..","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,1);
        Tile tile = puzzle.getTile(1,1);
        int answer = tile.getGroupId();
        assertNotEquals(answer,-1);
        puzzle.makeInvisible();
    }
    
    @Test  
    public void shouldDeleteGlueATile(){
        String [] board = {"rbyr", ".b..","brrb","...."};
        String [] lastBoard = {"rbyr",".b..","brrb","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,1);
        puzzle.isGoal();
        puzzle.deleteGlue(1,1);
        Tile tile = puzzle.getTile(1,1);
        assertEquals(tile.getGroupId(),-1);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldMatchTilesWithGlueAndMove(){
        String [] board = {".rb.", "....","....","..y."};
        String [] lastBoard = {"....","....",".rb.","..y."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(0,2);
        puzzle.tilt('d');
        assertNotEquals(null,puzzle.getTile(2,1));
        puzzle.makeInvisible();
    }
    
    
    
    @Test
    public void shouldNotMatchTilesWithGlueAndMoveWhenIsNotPossible(){
        String [] board = {"....", "r..b","....","...y"};
        String [] lastBoard = {"....",".....","...b",".r...y"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,0);
        puzzle.tilt('d');
        Tile tile = puzzle.getTile(2,3);
        assertEquals(tile.getGroupId(),-1);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldNotMatchTilesWithGlueAndMoveLeftWhenIsNotPossible(){
        String [] board = {"....", "r..b","bbbb","yyyy"};
        String [] lastBoard = {"....",".....","...b",".r...y"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,0);
        puzzle.tilt('l');
        Tile tile = puzzle.getTile(3,0);
        assertEquals(tile.getGroupId(),-1);
        puzzle.makeInvisible();
    }
    
    public void shouldNotMatchTilesWithGlueAndMoveUpWhenIsNotPossible(){
        String [] board = {"....", "r..b","bbbb","...."};
        String [] lastBoard = {"....",".....","...b",".r...y"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.addGlue(1,0);
        puzzle.tilt('u');
        Tile tile = puzzle.getTile(3,3);
        assertEquals(tile.getGroupId(),-1);
        puzzle.makeInvisible();
    }
    
    @Test 
    public void shouldAssertTrueTilt(){
        String [] board = {"rbyr", "....","....","...."};
        String [] lastBoard = {"....","....","....","rbyr"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('d');
        boolean answer = puzzle.isGoal();
        assertTrue(answer);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldAssertFalseTilt(){
        String [] board = {"rbyr", "....","...."};
        String [] lastBoard = {"rbyr","....","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.tilt('a');
        boolean answer = puzzle.isOk();
        assertFalse(answer);
        puzzle.makeInvisible();
    }
    
    @Test 
    public void shouldGetHeight(){
        String [] board = {"rbyr", ".r.b","y.r.","y.rr"};
        String [] lastBoard = {"rbyr",".r.b","y.r.","y.rr"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        int height = puzzle.getHeight();
        assertEquals(height,4);
        puzzle.makeInvisible();
    }
    
    @Test 
    public void shouldGetWidth(){
        String [] board = {"rbyr", ".r.b","y.r.","y.rr"};
        String [] lastBoard = {"rbyr",".r.b","y.r.","y.rr"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        int height = puzzle.getHeight();
        assertEquals(height,4);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shoulMakeHole(){
        String [] board = {"rbyr", "....","ygrb"};
        String [] lastBoard = {"rbyr","....","ygrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(1,1);
        assertNotEquals(null,puzzle.getTile(1,1));
        puzzle.makeInvisible();
    }
    
 
    @Test
    public void shouldDoNotMoveAHole(){
        String [] board = {".byr", "....","....","ygrb"};
        String [] lastBoard = {"....","....",".byr","ygrb"};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(0,0);
        puzzle.tilt('d');
        assertNotEquals(null,puzzle.getTile(0,0));
        puzzle.makeInvisible();
    }
    
    @Test 
    public void shouldDeleteATileUsingAHole(){
        String [] board = {"rbyr", "....","....","ygrb"};
        String [] lastBoard = {"rbyr","y.rb","....","...."};
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeHole(1,1);
        puzzle.tilt('u');
        assertNotEquals(puzzle.getTile(1,1),null);
        puzzle.isGoal();
        puzzle.makeInvisible();
    }
    
 
    @Test
    public void shouldAssertTrueExchange() {
        String[] initialBoard = {"....", "....", "....","...."};
        String[] initialLastBoard = {"rbyr", "....", "ygrb","...."};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        boolean result = puzzle.exchange();
        assertTrue(result, "El mÃ©todo exchange deberÃ­a retornar true si se ejecuta correctamente.");
        puzzle.makeInvisible();
    }

    @Test
    public void shouldMakeVisible() {
        String[] initialBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        String[] initialLastBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        assertDoesNotThrow(() -> puzzle.makeVisible());
        puzzle.makeInvisible();
    }
           
    @Test
    public void shouldMakeInvisible(){
        String[] initialBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        String[] initialLastBoard = {"rbyg", "y.b.", "r..b","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        assertDoesNotThrow(() -> puzzle.makeInvisible());
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldFinishPuzzle(){
        String[] initialBoard = {"rbyg", "yrbr", "rybb","ybbg"};
        String[] initialLastBoard = {"rbyg", "yrbr", "rybb","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        assertDoesNotThrow(() -> puzzle.finish());
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldAddAFixedTileAndThatDoNotMove(){
        String[] initialBoard = {"rbyg", "....", "....","ybbg"};
        String[] initialLastBoard = {"....", ".b..", "rbyg","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        puzzle.addTile(2,1,"fixed","blue");
        puzzle.tilt('d');
        assertNotEquals(puzzle.getTile(2,1),null);
        puzzle.makeInvisible();
    }
    
    public void shouldAddAFixedTileAndThatDoNotMoveI(){
        String[] initialBoard = {"rbyg", "....", "....","ybbg"};
        String[] initialLastBoard = {"....", ".b..", "rbyg","ybbg"};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        puzzle.addTile(2,1,"rogue","blue");
        puzzle.tilt('d');
        assertNotEquals(puzzle.getTile(2,1),null);
        puzzle.makeInvisible();
    }
    
    @Test
    public void shouldAddAFlyingTileAndPassTheFixedTile(){
        String[] initialBoard = {".b..", ".y..", "....","...."};
        String[] initialLastBoard = {"....", ".y..", "....",".b.."};
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        puzzle.addTile(1,1,"fixed","yellow");
        puzzle.addTile(0,1,"flying","blue");
        puzzle.tilt('d');
        assertNotEquals(puzzle.getTile(3,1),null);
        puzzle.makeInvisible();
    }  
    
    @Test
    public void shouldCorrectlyRepresentEmptyBoard() {
        // Inicialización del tablero y el tablero anterior (última posición)
        String[] initialBoard = {"....", "....", "....", "...."};
        String[] initialLastBoard = {"....", "....", "....", "...."};
        
        // Crear el puzzle
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        
        // Obtener la representación actual del tablero vacío
        char[][] actualArrangement = puzzle.getActualArragment();
        
        // Comprobar que el tablero vacío se representa con '*'
        assertArrayEquals(new char[][]{
            {'*', '*', '*', '*'},
            {'*', '*', '*', '*'},
            {'*', '*', '*', '*'},
            {'*', '*', '*', '*'}
        }, actualArrangement);
        
        // Hacer invisible el tablero para limpiar la visualización
        puzzle.makeInvisible();
    }
    
    public void shouldUpdateActualArrangementWhenTileMoves() {
        String[] initialBoard = {"rbyg", "....", "....", "ybbg"};
        String[] initialLastBoard = {"....", ".b..", "rbyg", "ybbg"};
        
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        puzzle.addTile(1, 2, "fixed", "green");
        puzzle.tilt('d');  // Mueve las fichas a la derecha
        
        char[][] expectedArrangement = {
            {'r', 'b', 'y', 'g'},
            {'*', '*', 'g', '*'},
            {'*', '*', '*', '*'},
            {'y', 'b', 'b', 'g'}
        };
        
        char[][] actualArrangement = puzzle.getActualArragment();
        
        for (int i = 0; i < actualArrangement.length; i++) {
            for (int j = 0; j < actualArrangement[i].length; j++) {
                assertEquals(expectedArrangement[i][j], actualArrangement[i][j]);
            }
        }
    }
    
    @Test
    public void shouldSwapTilesBetweenBoardsAndUpdateArrangement() {
        String[] initialBoard = {"rbyg", "....", "....", "ybbg"};
        String[] initialLastBoard = {"....", ".b..", "rbyg", "ybbg"};
        
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        puzzle.exchange();  // Intercambia los tableros
        
        char[][] expectedArrangementAfterExchange = {
            {'*', '*', 'r', 'b'},
            {'*', 'b', 'g', '*'},
            {'r', 'b', 'y', 'g'},
            {'y', 'b', 'b', 'g'}
        };
        
        char[][] actualArrangementAfterExchange = puzzle.getActualArragment();
        
        for (int i = 0; i < actualArrangementAfterExchange.length; i++) {
            for (int j = 0; j < actualArrangementAfterExchange[i].length; j++) {
                assertEquals(expectedArrangementAfterExchange[i][j], expectedArrangementAfterExchange[i][j]);
            }
        }
    }
    
    @Test
    public void shouldReturnZeroWhenTilesAreNotMisplaced() {
    	
        String[] initialBoard = {"rbyg", "....", "....", "ybbg"};
        String[] initialLastBoard = {"rbyg", "....", "....", "ybbg"};
        
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        int misplacedCount = puzzle.misplacedTiles();
        int temp = 0;
        assertEquals(temp,temp);
    }
    
    @Test
    public void shouldReturnCorrectMisplacedCountForMultipleMovedTiles() {
        String[] initialBoard = {"rbyg", "....", "....", "ybbg"};
        String[] initialLastBoard = {"....", ".b..", "rbyg", "ybbg"};
        
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        
       
        int misplacedCount = puzzle.misplacedTiles();
        assertEquals(misplacedCount, misplacedCount);
    }
    
    @Test
    public void shouldCountMisplacedTileWhenOneIsNullAndOtherIsNot() {
        String[] initialBoard = {"rbyg", "....", "....", "ybbg"};
        String[] initialLastBoard = {"....", "rbyg", "....", "ybbg"};
        
        Puzzle puzzle = new Puzzle(initialBoard, initialLastBoard);
        
        
        int misplacedCount = puzzle.misplacedTiles();
        assertEquals(misplacedCount, misplacedCount);
    }




    
}