package test;
import javax.swing.JOptionPane;

import domain.*;

public class MainProblemTest {

    public static void main(String[] args) {

        String [] board = new String[8];
        String [] lastBoard = new String[8];
        for (int i = 0; i < 8; i++) {
            board[i] = "........";
            lastBoard[i] = "........";
        }
        Puzzle puzzle = new Puzzle(board,lastBoard);
        puzzle.makeVisible();
        //Espera 5 segundos
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        //Probar funcionamiento normal
        puzzle.addTile(0, 0, "Normal", "red");
        puzzle.addTile(0, 1, "Normal", "red");
        
        moveUpDown(puzzle);

        //Probar funcionamiento fixed
        puzzle.addTile(0, 2, "Fixed", "yellow");
        moveUpDown(puzzle);

        //Probar funcionamiento rough
        puzzle.addTile(0, 3, "Rough", "blue");
        moveUpDown(puzzle);

        
        //Probar funcionamiento freelance
        puzzle.addTile(1, 5, "Normal", "red");
        puzzle.addTile(1, 6, "Normal", "red");
        puzzle.addTile(2, 6, "Normal", "red");
        puzzle.addTile(1, 7, "Freelance", "green");

        puzzle.addGlue(1, 6);

        moveUpDown(puzzle);
        moveLeftRight(puzzle);
        
        String mensaje = "Moviendose a abajo";
        int opcion = JOptionPane.showConfirmDialog(null, mensaje, "Confirmación", JOptionPane.OK_CANCEL_OPTION);

        if (opcion == JOptionPane.OK_OPTION) {
            puzzle.tilt('d');
        }
        puzzle.addTile(0, 6, "Normal", "red");

        moveUpDown(puzzle);
        moveLeftRight(puzzle);
        
        puzzle.makeHole(7, 0);
        puzzle.addTile(0, 4, "flying", "green");
        puzzle.makeHole(7, 4);

        moveUpDown(puzzle);
    }

    private static void moveUpDown(Puzzle puzzle) {
        String mensaje = "Moviendose a abajo";
        int opcion = JOptionPane.showConfirmDialog(null, mensaje, "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        
        if (opcion == JOptionPane.OK_OPTION) {
            puzzle.tilt('d');
        }
        mensaje = "Moviendose a arriba";
        opcion = JOptionPane.showConfirmDialog(null, mensaje, "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        
        if (opcion == JOptionPane.OK_OPTION) {
            puzzle.tilt('u');
        }
    }

    private static void moveLeftRight(Puzzle puzzle) {
        String mensaje = "Moviendose a la izquierda";
        int opcion = JOptionPane.showConfirmDialog(null, mensaje, "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        
        if (opcion == JOptionPane.OK_OPTION) {
            puzzle.tilt('l');
        }
        mensaje = "Moviendose a la derecha";
        opcion = JOptionPane.showConfirmDialog(null, mensaje, "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        
        if (opcion == JOptionPane.OK_OPTION) {
            puzzle.tilt('r');
        }
    }
    
}
