package test;

import javax.swing.JOptionPane;
import domain.*;

public class MainProblemTest2 {

    public static void main(String[] args) {
        
        // Inicialización del tablero y estado anterior
        String[] board = new String[8];
        String[] lastBoard = new String[8];
        for (int i = 0; i < 8; i++) {
            board[i] = "........";
            lastBoard[i] = "........";
        }
        
        Puzzle puzzle = new Puzzle(board, lastBoard);
        puzzle.makeVisible();

        // Configuración básica: Añadir fichas normal, fija, áspera y voladora
        puzzle.addTile(1,1 , "Normal", "red");      // Ficha normal
        puzzle.addTile(1, 0, "Fixed", "yellow");    // Ficha fija
        puzzle.addTile(0, 0, "Rough", "blue");      // Ficha áspera
        puzzle.addTile(2, 2, "Flying", "green");    // Ficha voladora

        // Mover hacia la derecha y verificar que la ficha fija bloquea
        confirmAndMove(puzzle, 'r', "Mover hacia la derecha");

        // Mover hacia abajo y confirmar que la ficha normal se mueve
        confirmAndMove(puzzle, 'd', "Mover hacia abajo");

        // Probar movimiento hacia la izquierda para confirmar que la ficha áspera bloquea el paso
        confirmAndMove(puzzle, 'l', "Mover hacia la izquierda (ficha áspera debería bloquear)");

        // Probar movimiento hacia arriba y confirmar que la ficha voladora se comporta correctamente
        confirmAndMove(puzzle, 'u', "Mover hacia arriba (ficha voladora evita obstáculos)");

        // Probar el método exchange entre la ficha normal y la ficha voladora
        int exchangeOption = JOptionPane.showConfirmDialog(null, "¿Desea intercambiar la ficha normal y la voladora?", "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        if (exchangeOption == JOptionPane.OK_OPTION) {
            puzzle.exchange();  // Intercambia posiciones entre la ficha normal y la ficha voladora
        }

        // Estado final
        int finalOption = JOptionPane.showConfirmDialog(null, "¿Desea ver el estado final del tablero?", "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        
    }

    private static void confirmAndMove(Puzzle puzzle, char direction, String message) {
        int option = JOptionPane.showConfirmDialog(null, message, "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            puzzle.tilt(direction);
        }
    }
}