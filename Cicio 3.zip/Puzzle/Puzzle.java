
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Puzzle {
    private int height;
    private int width;
    private Tile[][] board;
    private Tile[][] lastBoard;
    private String[] order;
    private boolean[][] hole;

    public Puzzle(int height, int width) {
        this.height = height;
        this.width = width;
        this.board = new Tile[width][height];
        this.lastBoard = new Tile[width][height];
        this.hole = new boolean[width][height];
        this.createBoards();
    }

    public Puzzle(String[] ending) {
        this.height = ending.length;
        this.width = ending[0].length();
        this.createlastBoardByOrder(ending);
        this.createBoardsAutomatically();
    }

    public Puzzle(String[] starting, String[] ending) {
        this.height = ending.length;
        this.width = ending[0].length();
        this.createlastBoardByOrder(ending);
        this.createBoardByOrder(starting);
    }

    public void makeVisible() {
        this.background(this.height, this.width);

        for (int i = 0; i < this.height; ++i) {
            for (int j = 0; j < this.width; ++j) {
                if (this.board[i][j] != null) {
                    this.board[i][j].makeVisible();
                } else {
                    this.board[i][j] = null;
                }

                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].makeVisible();
                } else {
                    this.lastBoard[i][j] = null;
                }
            }
        }

    }

    private void createlastBoardByOrder(String[] cadena) {
        int numFilas = cadena.length;
        int numColumnas = cadena[0].length();
        this.lastBoard = new Tile[numFilas][numColumnas];

        for (int i = 0; i < numFilas; ++i) {
            for (int j = 0; j < numColumnas; ++j) {
                char c = cadena[i].charAt(j);
                switch (c) {
                    case '.' -> this.lastBoard[i][j] = null;
                    case 'b' -> this.lastBoard[i][j] = new Tile("blue");
                    case 'g' -> this.lastBoard[i][j] = new Tile("green");
                    case 'r' -> this.lastBoard[i][j] = new Tile("red");
                    case 'y' -> this.lastBoard[i][j] = new Tile("yellow");
                    default -> throw new IllegalArgumentException("Carácter no reconocido: " + c);
                }

                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].setXY(i, j);
                    this.lastBoard[i][j].moveHorizontal(500);
                }
            }
        }

    }

    private void createBoardByOrder(String[] cadena) {
        int numFilas = cadena.length;
        int numColumnas = cadena[0].length();
        this.board = new Tile[numFilas][numColumnas];

        for (int i = 0; i < numFilas; ++i) {
            for (int j = 0; j < numColumnas; ++j) {
                char c = cadena[i].charAt(j);
                switch (c) {
                    case '.' -> this.board[i][j] = null;
                    case 'b' -> this.board[i][j] = new Tile("blue");
                    case 'g' -> this.board[i][j] = new Tile("green");
                    case 'r' -> this.board[i][j] = new Tile("red");
                    case 'y' -> this.board[i][j] = new Tile("yellow");
                    default -> throw new IllegalArgumentException("Carácter no reconocido: " + c);
                }

                if (this.board[i][j] != null) {
                    this.board[i][j].setXY(i, j);
                }
            }
        }

    }

    private void background(int height, int width) {
        Rectangle background = new Rectangle();
        Rectangle backgroundS = new Rectangle();
        background.changeSize(width * 51, height * 51);
        backgroundS.changeSize(width * 51, height * 51);
        background.changeColor("Grey");
        backgroundS.changeColor("Grey");
        background.makeVisible();
        background.moveTo(62, 14);
        backgroundS.moveTo(565, 14);
        backgroundS.makeVisible();
    }

    private void createBoards() {
        String[] colors = new String[]{"red", "yellow", "blue", "green"};
        int totalTiles = this.height * this.width;
        int colorTiles = totalTiles / 2;
        int emptyTiles = totalTiles - colorTiles;
        ArrayList<Tile> tiles = new ArrayList();
        ArrayList<Tile> tilesFinal = new ArrayList();

        int temp;
        for (temp = 0; temp < colorTiles; temp++) {
            Tile tile = new Tile(colors[temp % 4]);
            Tile tileFinal = new Tile(colors[temp % 4]);
            tiles.add(tile);
            tilesFinal.add(tileFinal);
        }

        for (temp = 0; temp < emptyTiles; ++temp) {
            tiles.add(null);
            tilesFinal.add(null);
        }

        Collections.shuffle(tiles);
        Collections.shuffle(tilesFinal);
        temp = 0;
        int tempF = 0;

        for (int i = 0; i < this.height; i++) {
            for (int j = 0; j < this.width; j++) {
                this.board[i][j] = (Tile) tiles.get(temp++);
                this.lastBoard[i][j] = (Tile) tilesFinal.get(tempF++);
                if (this.board[i][j] != null) {
                    this.board[i][j].setXY(i, j);
                }

                if (this.lastBoard[i][j] != null) {
                    this.lastBoard[i][j].setXY(i, j);
                    this.lastBoard[i][j].moveHorizontal(500);
                }
            }
        }

    }

    private void createBoardsAutomatically() {
        String[] colors = new String[]{"red", "yellow", "blue", "green"};
        int totalTiles = this.height * this.width;
        int colorTiles = totalTiles / 2;
        int emptyTiles = totalTiles - colorTiles;
        ArrayList<Tile> tiles = new ArrayList();

        int temp;
        for (temp = 0; temp < colorTiles; ++temp) {
            Tile tile = new Tile(colors[temp % 4]);
            tiles.add(tile);
        }

        for (temp = 0; temp < emptyTiles; ++temp) {
            tiles.add(null);
        }

        Collections.shuffle(tiles);
        temp = 0;
        this.board = new Tile[this.height][this.width];

        for (int i = 0; i < this.height; ++i) {
            for (int j = 0; j < this.width; ++j) {
                this.board[i][j] = (Tile) tiles.get(temp++);
                if (this.board[i][j] != null) {
                    this.board[i][j].setXY(i, j);
                }
            }
        }

    }

    public int getHeight() {
        return this.height;
    }

    public int getWidth() {
        return this.width;
    }

    private void setTile(int row, int column, Tile tile) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            this.board[row][column] = tile;
        }

    }

    public void addTile(int row, int column, String color) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            Tile newTile = new Tile(color);
            newTile.setXY(row, column);
            setTile(row, column, newTile);
            newTile.makeVisible();
        } else {
            System.out.println("Posición fuera de los límites del tablero.");
        }

    }

    private void addTileToRelocate(int row, int column, String color, boolean hasGlue, int groupId) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            Tile newTile = new Tile(color);
            newTile.setXY(row, column);
            if (hasGlue) {
                newTile.glue();
            }
            this.setTile(row, column, newTile);
            newTile.setGroupId(groupId);
            newTile.makeVisible();
        } else {
            System.out.println("Posición fuera de los límites del tablero.");
        }

    }

    public void deleteTile(int row, int column) {
        if (row >= 0 && row < this.height && column >= 0 && column < this.width) {
            Tile tile = this.getTile(row, column);
            if (tile != null) {
                this.board[row][column] = null;
                tile.makeInvisible();
            }
        }

    }

    public void relocateTile(int oldRow, int oldColumn, int newRow, int newColumn) {
        if (oldRow >= 0 && oldRow < this.height && oldColumn >= 0 && oldColumn < this.width && newRow >= 0 && newRow < this.height && newColumn >= 0 && newColumn < this.width) {
            Tile tile = this.getTile(oldRow, oldColumn);
            if (tile != null && this.board[newRow][newColumn] == null && !tile.getColor().equals("white")) {
                deleteTile(oldRow, oldColumn);
                String color = tile.getColor();
                int group = tile.getGroupId();
                boolean hasGlue = tile.hasGlue();
                addTileToRelocate(newRow, newColumn, color, hasGlue, group);
            }
        }

    }


    public void addGlue(int row, int col) {
        if (row >= 0 && row < this.height && col >= 0 && col < this.width && this.board[row][col] != null) {
            Tile tile = this.board[row][col];
            tile.glue();
            if (tile.getGroupId() == -1) {
                Tile.createGroup(tile);
            }

            int id = tile.getGroupId();
            if (row > 0 && this.board[row - 1][col] != null) {
                this.board[row - 1][col].addGroup(this.board[row - 1][col], id);
            }

            if (row < this.height - 1 && this.board[row + 1][col] != null) {
              this.board[row + 1][col].addGroup(this.board[row + 1][col], id);
            }

            if (col > 0 && this.board[row][col - 1] != null) {
                this.board[row][col - 1].addGroup(this.board[row][col - 1], id);
            }

            if (col < this.width - 1 && this.board[row][col + 1] != null) {
                this.board[row][col + 1].addGroup(this.board[row][col + 1], id);
            }
        }

    }
    public void tilt(char direction) {
        int row;
        int col;
        Tile tile;
        switch (direction) {
            case 'd':
                this.moveTileDownTotal();
                return;
            case 'l':
                this.moveTileLeftTotal();
                return;
            case 'r':
                this.moveTileRightTotal();
                return;
            case 'u':
                this.moveTileUpTotal();
                return;

            default:
                System.out.println("Dirección no válida");
        }
    }

    private void moveTileUpTotal() {
        Tile tile;
        int row;
        int col;
        for (row = 0; row < this.height; ++row) {
            for (col = 0; col < this.width; ++col) {
                tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() == -1) {
                    this.moveTileUp(row, col);
                }
            }
        }

        for (row = 0; row < this.height; ++row) {
            for (col = 0; col < this.width; ++col) {
                tile = this.getTile(row, col);
                if (tile != null && tile.getGroupId() != -1) {
                    this.moveTileUpGroups(row, col);
                }
            }
        }
    }

    private void moveTileUp(int fila, int columna) {
        for (int i = fila - 1; i >= 0; --i) {
            if (this.hole[i][columna]) {
                this.deleteTile(fila, columna);
                break;
            }

            if (i == 0) {
                this.relocateTile(fila, columna, i, columna);
                break;
            }

            Tile tile = this.getTile(i - 1, columna);
            if (tile != null && !this.hole[i - 1][columna]) {
                this.relocateTile(fila, columna, i, columna);
                break;
            }
        }

    }

    private void moveTileUpGroups(int fila, int columna) {
        Tile tile = this.getTile(fila, columna);
        int minMovimientos = this.minCalculateMovementsUp(tile.getGroupId());
        System.out.println("El mínimo de movimientos para el grupo " + " es: " + minMovimientos);

        for (int i = fila - 1; i >= 0; --i) {
            if (i == 0) {
                this.relocateTile(fila, columna, fila - minMovimientos, columna);
                break;
            }

            this.getTile(i - 1, columna);
            if (tile != null && !this.hole[i - 1][columna]) {
                this.relocateTile(fila, columna, fila - minMovimientos, columna);
                break;
            }
        }

    }

    private int calculateMovementsUp(Tile tile, int fila, int columna) {
        int movements = 0;
        for (int i = fila - 1; i >= 0; --i) {
            Tile tileI = this.getTile(i, columna);
            if (tileI != null) {
                break;
            }
            movements++;
        }
        return movements;
    }

    private int minCalculateMovementsUp(int groupId) {
        int minMovements = 10000;
        for (int row = 0; row <= this.height; row++) {
            for (int col = 0; col <= this.width; col++) {
                Tile tile = this.getTile(row, col);
                System.out.print("llegamos" + "\n");
                if (tile != null && tile.getGroupId() == groupId) {
                    System.out.print(calculateMovementsUp(tile, row, col) + "-" + minMovements + "\n");
                    if (minMovements > calculateMovementsUp(tile, row, col)) {
                        minMovements = calculateMovementsUp(tile, row, col);
                    }
                }
            }
        }
        return minMovements;
    }

    private void moveTileDownTotal(){
        Tile tile;
        int row;
        int col;
        for (row = this.height - 1; row >= 0; --row) {
            for (col = 0; col < this.width; ++col) {
                tile = this.getTile(row, col);
                if (tile != null) {
                    this.moveTileDown(row, col);
                }
            }
        }
        for (row = this.height - 1; row >= 0; --row) {
            for (col = 0; col < this.width; ++col) {
                tile = this.getTile(row, col);
                if (tile != null) {
                    this.moveTileDownGroups(row, col);
                }
            }
        }
        for (row = this.height - 1; row >= 0; --row) {
            for (col = 0; col < this.width; ++col) {
                tile = this.getTile(row, col);
                if (tile != null) {
                    this.moveTileDown(row, col);
                }
            }
        }
    }

    private void moveTileDown(int fila, int columna) {
        for(int i = fila + 1; i < this.height; ++i) {
            if (this.hole[i][columna]) {
                this.deleteTile(fila, columna);
                break;
            }

            if (i == this.height - 1) {
                this.relocateTile(fila, columna, i, columna);
                break;
            }

            Tile tile = this.getTile(i + 1, columna);
            if (tile != null && !this.hole[i + 1][columna]) {
                this.relocateTile(fila, columna, i, columna);
                break;
            }
        }
    }

    private void moveTileDownGroups(int fila, int columna) {
        Tile tile = this.getTile(fila, columna);
        int minMovimientos = this.minCalculateMovementsDown(tile.getGroupId());

        for(int k = 0; k < minMovimientos; ++k) {
            for(int i = fila + 1; i < this.height ; ++i) {
                if (this.hole[i][columna]) {
                    this.deleteTile(fila, columna);
                    break;
                }

                if (i == 0) {
                    this.relocateTile(fila, columna, i, columna);
                    break;
                }

                this.getTile(i - 1, columna);
                if (tile != null && !this.hole[i - 1][columna]) {
                    this.relocateTile(fila, columna, i, columna);
                    break;
                }
            }
        }

    }

    private int calculateMovementsDown(Tile tile, int fila, int columna) {
        int movements = 0;
        for(int i = fila - 1; i >= 0; --i) {
            Tile tileI = this.getTile(i, columna);
            if (tileI != null) {
                break;
            }
            ++movements;
        }
        return movements;
    }

    private int minCalculateMovementsDown(int groupId) {
        int minimoMovimiento = Integer.MAX_VALUE;

        for(int i = 0; i < this.height; ++i) {
            for(int j = 0; j < this.width; ++j) {
                Tile tile = this.getTile(i, j);
                if (tile != null && tile.getGroupId() == groupId) {
                    int movimientos = this.calculateMovementsDown(tile, i, j);
                    if (movimientos < minimoMovimiento) {
                        minimoMovimiento = movimientos;
                    }
                }
            }
        }

        return minimoMovimiento;
    }

    private void moveTileLeftTotal(){
        Tile tile;
        int row;
        int col;

        for (row = 0; row < this.width; ++row) {
            for (col = 0; col < this.height; ++col) {
                tile = this.getTile(col, row);
                if (tile != null) {
                    this.moveTileLeft(col, row);
                }
            }
        }
        for (row = 0; row < this.width; ++row) {
            for (col = 0; col < this.height; ++col) {
                tile = this.getTile(col, row);
                if (tile != null) {
                    this.moveTileLeftByGroups(col, row);
                }
            }
        }
        for (row = 0; row < this.width; ++row) {
            for (col = 0; col < this.height; ++col) {
                tile = this.getTile(col, row);
                if (tile != null) {
                    this.moveTileLeft(col, row);
                }
            }
        }
    }

    private void moveTileLeft(int row, int col) {
        for(int j = col - 1; j >= 0; --j) {
            if (this.hole[row][j]) {
                this.deleteTile(row, col);
                break;
            }

            if (j == 0) {
                this.relocateTile(row, col, row, j);
                break;
            }

            Tile tile = this.getTile(row, j - 1);
            if (tile != null && !this.hole[row][j - 1]) {
                this.relocateTile(row, col, row, j);
                break;
            }
        }

    }

    private void moveTileLeftByGroups(int row, int col) {
        Tile tile = this.getTile(row, col);
        int minMovimientos = this.minCalculateMovementsLeft(tile.getGroupId());

        for(int j = col - 1; j >= 0; --j) {
            if (this.hole[row][j]) {
                this.deleteTile(row, col);
                break;
            }

            if (j == 0) {
                this.relocateTile(row, col, row, j);
                break;
            }

            this.getTile(row, j - 1);
            if (tile != null && !this.hole[row][j - 1]) {
                this.relocateTile(row, col, row, j);
                break;
            }
        }

    }
    private int calculateMovementsLeft(Tile tile, int fila, int columna) {
        int movements = 0;

        for(int i = fila - 1; i >= 0; --i) {
            Tile tileI = this.getTile(i, columna);
            if (tileI != null) {
                break;
            }

            ++movements;
        }

        return movements;
    }

    private int minCalculateMovementsLeft(int groupId) {
        int minimoMovimiento = Integer.MAX_VALUE;

        for(int i = 0; i < this.height; ++i) {
            for(int j = 0; j < this.width; ++j) {
                Tile tile = this.getTile(i, j);
                if (tile != null && tile.getGroupId() == groupId) {
                    int movimientos = this.calculateMovementsLeft(tile, i, j);
                    if (movimientos < minimoMovimiento) {
                        minimoMovimiento = movimientos;
                    }
                }
            }
        }

        return minimoMovimiento;
    }
    private void moveTileRightTotal(){
        Tile tile;
        int row;
        int col;
        for (row = this.width - 1; row >= 0; --row) {
            for (col = 0; col < this.height; ++col) {
                tile = this.getTile(col, row);
                if (tile != null) {
                    this.moveTileRight(col, row);
                }
            }
        }
        for (row = this.width - 1; row >= 0; --row) {
            for (col = 0; col < this.height; ++col) {
                tile = this.getTile(col, row);
                if (tile != null) {
                    this.moveTileRightByGroups(col, row);
                }
            }
        }
        for (row = this.width - 1; row >= 0; --row) {
            for (col = 0; col < this.height; ++col) {
                tile = this.getTile(col, row);
                if (tile != null) {
                    this.moveTileRight(col, row);
                }
            }
        }
    }

    private void moveTileRight(int row, int col) {
        for(int j = col + 1; j < this.width; ++j) {
            if (this.hole[row][j]) {
                this.deleteTile(row, col);
                break;
            }

            if (j == this.width - 1) {
                this.relocateTile(row, col, row, j);
                break;
            }

            Tile tile = this.getTile(row, j + 1);
            if (tile != null && !this.hole[row][j + 1]) {
                this.relocateTile(row, col, row, j);
                break;
            }
        }

    }

    private void moveTileRightByGroups(int row, int col) {
        Tile tile = this.getTile(row, col);
        int minMovimientos = this.minCalculateMovementsLeft(tile.getGroupId());

        for(int j = col - 1; j >= 0; --j) {
            if (this.hole[row][j]) {
                this.deleteTile(row, col);
                break;
            }

            if (j == 0) {
                this.relocateTile(row, col, row, j);
                break;
            }

            this.getTile(row, j - 1);
            if (tile != null && !this.hole[row][j - 1]) {
                this.relocateTile(row, col, row, j);
                break;
            }
        }

    }
    private int calculateMovementsRight(Tile tile, int fila, int columna) {
        int movements = 0;
        for(int i = fila - 1; i >= 0; --i) {
            Tile tileI = this.getTile(i, columna);
            if (tileI != null) {
                break;
            }
            movements++;
        }

        return movements;
    }

    private int minCalculateMovementsRight(int groupId) {
        int minimoMovimiento = Integer.MAX_VALUE;

        for(int i = 0; i < this.height; ++i) {
            for(int j = 0; j < this.width; ++j) {
                Tile tile = this.getTile(i, j);
                if (tile != null && tile.getGroupId() == groupId) {
                    int movimientos = this.calculateMovementsLeft(tile, i, j);
                    if (movimientos < minimoMovimiento) {
                        minimoMovimiento = movimientos;
                    }
                }
            }
        }

        return minimoMovimiento;
    }


    public void makeHole(int row, int col) {
        if (row <= this.height && row >= 0 && col <= this.width && col >= 0 && !this.hole[row][col]) {
            this.hole[row][col] = true;
            Tile tile = this.getTile(row, col);
            if (tile != null) {
                this.deleteTile(row, col);
            }

            this.addTile(row, col, "white");
        }
    }

    public int misplacedTiles() {
        int height = board.length;
        int width = board[0].length;
        int misplaceCount = 0;

        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width; col++) {
                Tile tile1 = board[row][col];
                Tile tile2 = lastBoard[row][col];
                if (tile1 == null && tile2 != null || tile1 != null && tile2 == null) {
                    misplaceCount++;
                } else if (tile1 != null && tile2 != null && !tile1.equals(tile2)) {
                    misplaceCount++;
                }
            }
        }
        return misplaceCount;
    }

    public Tile getTile(int x, int y) {
        if (x >= 0 && x < this.height && y >= 0 && y < this.width) {
            return this.board[x][y];
        } else {
            return null;
        }
    }

}



