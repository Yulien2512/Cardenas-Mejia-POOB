import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.HashSet;


public class Tile {
    private Rectangle tile;         // Representación gráfica de la ficha
    private boolean hasGlue;        // Si la ficha tiene pegamento
    private boolean moved;
    private List<Tile> group;
    private int groupId;// Indica si la ficha se ha movido
    private int x;                  // Coordenada X de la ficha en el tablero
    private int y;                     // Coordenada Y de la ficha en el tablero
    private static int groupCounter = 0;
    /**
     * Constructor de la clase Tile
     *
     * @param color Color de la ficha
     */
    public Tile(String color) {
        this.tile = new Rectangle();
        this.tile.changeSize(40, 40);
        this.tile.changeColor(color);
        this.hasGlue = false;
        this.group = new ArrayList<>();
        this.group.add(this); // Cada ficha se añade a su propio grupo inicialmente
        this.groupId = -1;
        this.moved = false;
    }

    /**
     * Establece las coordenadas (x, y) de la ficha y mueve el objeto gráfico a esa posición.
     *
     * @param x Coordenada X en el tablero
     * @param y Coordenada Y en el tablero
     */
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y ;
        tile.moveVertical(x * 50);
        tile.moveHorizontal(y * 50);
    }

    public int getRow() {
        return x;
    }
    public int getCol() {
        return y;
    }

    public int getGroupId() {
        return this.groupId; // Devuelve el ID del grupo
    }

    public void addGroup(Tile tile, int id) {
        tile.setGroupId(id); // Establecer el ID del grupo directamente en la ficha
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public static void createGroup(Tile tile) {
        int newGroupId = ++groupCounter; // Incrementar el contador y asignar un nuevo ID
        tile.setGroupId(newGroupId); // Asignar el nuevo ID a la ficha
    }

    public static int countGroups() {
        return groupCounter; // Devolver el contador de grupos
    }
    /**
     * Muestra la ficha en la interfaz gráfica.
     */
    public void makeVisible() {
        tile.makeVisible();
    }

    public void makeInvisible() {
        tile.makeInvisible();
    }

    public void moveHorizontal(int distance) {
        tile.moveHorizontal(distance);
    }

    /**
     * Añade pegamento a la ficha y busca fichas adyacentes para conectarlas.
     */
    public void glue(){
        this.hasGlue = true;
        Circle circle;
        

    }

    public boolean hasGlue() {
        return hasGlue;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    /**
     * Mueve la ficha y las fichas conectadas si hay pegamento.
     *
     * @param x Nueva coordenada X
     * @param y Nueva coordenada Y
     */



    public String getColor() {
        return tile.getColor();
    }

    public boolean getMoved() {
        return moved;
    }

    public void setMoved(boolean moved) {
        this.moved = moved;
    }
}


